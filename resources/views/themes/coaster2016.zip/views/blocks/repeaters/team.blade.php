@if ($is_first)
    <div class="row text-center meetrow">
@endif

        <div class="col-sm-4">
            {!! PageBuilder::block('member_image') !!}
            <h3>{!! PageBuilder::block('member_name') !!}</h3>
            <p>{!! PageBuilder::block('member_text') !!}</p>
        </div>

@if ($is_last)
    </div>
@endif

