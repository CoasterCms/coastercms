<div class="row">
    <div class="col-sm-12">
        <div class="videoWrapper">
            <iframe style="border:0;padding-bottom:15px;" width="592" height="333" src="http://www.youtube.com/embed/{!! $video->id !!}" allowfullscreen></iframe>
        </div>
    </div>
</div>