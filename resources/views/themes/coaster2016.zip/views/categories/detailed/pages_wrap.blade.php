<div class="row category-detailed">
    {!! $pages !!}
</div>