<ul>
{!! $pages !!}
</ul>