<div class="row">
    {!! $pages !!}
</div>