{!! $pages !!}
<hr />