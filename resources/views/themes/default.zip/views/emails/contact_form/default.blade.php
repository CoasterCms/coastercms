A new contact message has been sent:

------------------------------
{!! $body !!}